namespace Stegosaurus {
    public abstract class Steganography {
        public abstract void Encode();
        public abstract void Decode();
    }
}
