﻿namespace Stegosaurus {
    public interface IImageDecoder {
        byte[] Decode();
    }
}